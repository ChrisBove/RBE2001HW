Name: Christopher Bove
Username: cpbove

Files:

  lab1.c - c source code for Lab 1 hello program
  leap.c - c source code for leap year program
  makefile - c code compiling configuration, makes .o's and executables
  num.c - c source code file for number printing program
  readme.txt (this file) - readme for this directory

To compile code:
  Have standard gcc compiler. Type "make" in the terminal within this 
directory to make three executable files from code mentioned above. Doing 
"make" will create object files from each source code file and automatically
link them appropriately to create executables. See makefile for details.
