/**
 * @file mystrlen.h
 * @author Christopher Bove (cpbove)
 * @date  April 2015
 * @brief Header file for assignment 4 string counting function
 *
 */

#ifndef MYSTRLEN_H
#define MYSTRLEN_H

int mystrlen(const char *s);

#endif
