Name: Christopher Bove
Username: cpbove

Files:

  assg2.c - c source code for assignment 1 program
  num2.c - c source code for lab num test program
  makefile - c code compiling configuration, makes .o's and executables
  readme.txt (this file) - readme for this directory

To compile code:
  Have standard gcc compiler. Type "make" in the terminal within this 
directory to make three executable files from code mentioned above. Doing 
"make" will create object files from each source code file and automatically
link them appropriately to create executables. See makefile for details.