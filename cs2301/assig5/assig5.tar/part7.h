#ifndef PART7_H
#define PART7_H

int readEmployeeLog(int index, char* name, int* salary);
int numEmployees();
#endif
