#ifndef PART5_H
#define PART5_H

int readEmployeeLog(int index, char* name, int* salary);
int numEmployees();
#endif
